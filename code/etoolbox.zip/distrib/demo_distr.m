% PURPOSE: demo all distribution functions

beta_d

bino_d

chis_d

fdis_d

gamm_d

hypg_d

logn_d

logt_d

normc_d

normlt_d

normrt_d

normt_d

pois_d

stdn_d

tdis_d

trunc_d

unif_d

wish_d
